
using Core.Shared.Models;
using System.IO.Compression;
using System.Text.Json;

namespace Core.Upstox;

public sealed class InstrumentsService : IInstrumentsService
{
    private readonly string _dbPath;
    private Dictionary<string, InstrumentInfo>? _bySymbol;

    public InstrumentsService(string dataDir)
    {
        Directory.CreateDirectory(dataDir);
        _dbPath = Path.Combine(dataDir, "instruments_cache.json");
    }

    public async Task EnsureCacheAsync(bool sandbox, CancellationToken ct)
    {
        if (_bySymbol != null) return;
        if (!File.Exists(_dbPath))
        {
            var url = "https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz"; // BOD JSON
            using var http = new HttpClient();
            using var stream = await http.GetStreamAsync(url, ct);
            using var gz = new GZipStream(stream, CompressionMode.Decompress);
            using var ms = new MemoryStream();
            await gz.CopyToAsync(ms, ct);
            ms.Position = 0;
            using var doc = await JsonDocument.ParseAsync(ms, cancellationToken: ct);

            var temp = new Dictionary<string, InstrumentInfo>(StringComparer.OrdinalIgnoreCase);
            foreach (var el in doc.RootElement.EnumerateArray())
            {
                var segment = el.GetProperty("segment").GetString() ?? "";
                var instType = el.GetProperty("instrument_type").GetString() ?? "";
                if (segment != "NSE_EQ" || instType != "EQ") continue;
                var trading = el.GetProperty("trading_symbol").GetString() ?? "";
                var key = el.GetProperty("instrument_key").GetString() ?? "";
                var isin = el.GetProperty("isin").GetString() ?? "";
                var lot = el.TryGetProperty("lot_size", out var lotEl) ? lotEl.GetInt32() : 1;
                var freeze = el.TryGetProperty("freeze_quantity", out var fEl) ? fEl.GetDecimal() : 0m;
                var tick = el.TryGetProperty("tick_size", out var tEl) ? tEl.GetDecimal() : 0m;
                temp[trading] = new InstrumentInfo(key, trading, segment, instType, isin, lot, freeze, tick);
            }
            await File.WriteAllTextAsync(_dbPath, JsonSerializer.Serialize(temp));
            _bySymbol = temp;
        }
        else
        {
            var json = await File.ReadAllTextAsync(_dbPath, ct);
            _bySymbol = JsonSerializer.Deserialize<Dictionary<string, InstrumentInfo>>(json) ?? new();
        }
    }

    public Task<InstrumentInfo?> FindByTradingSymbolAsync(string tradingSymbol, string segment = "NSE_EQ", string instrumentType = "EQ")
    {
        _bySymbol ??= new();
        _bySymbol.TryGetValue(tradingSymbol.ToUpperInvariant(), out var info);
        return Task.FromResult(info);
    }
}
