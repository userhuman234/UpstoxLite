
namespace Core.Shared.Models;

public enum Product { I, D, MTF }
public enum OrderType { MARKET, LIMIT, SL, SL_M }
public enum Validity { DAY, IOC }
public enum Txn { BUY, SELL }

public record PlaceOrder(
    string InstrumentKey,
    int Quantity,
    Product Product,
    OrderType OrderType,
    Txn TransactionType,
    Validity Validity = Validity.DAY,
    decimal Price = 0m,
    decimal TriggerPrice = 0m,
    bool IsAmo = false,
    bool Slice = false,
    string? Tag = null
);

public record MultiOrderLine(
    string CorrelationId,
    PlaceOrder Order
);
