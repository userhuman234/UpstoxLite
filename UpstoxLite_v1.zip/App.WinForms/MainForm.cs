
using Core.Engine;
using Core.Shared.Models;
using Core.Upstox;
using System.Text.Json;

namespace App.WinForms;

public partial class MainForm : Form
{
    private readonly Config _config;
    private readonly IAuthService _auth;
    private readonly IInstrumentsService _inst;
    private readonly IOrderClient _orders;
    private readonly IStrategyHost _strategies;

    private string? _accessToken;
    private bool Sandbox => (cmbEnv.SelectedItem?.ToString() ?? _config.Environment) == "Sandbox";

    public MainForm(Config config, IAuthService auth, IInstrumentsService inst, IOrderClient orders, IStrategyHost strategies)
    {
        InitializeComponent();
        _config = config; _auth = auth; _inst = inst; _orders = orders; _strategies = strategies;
        cmbEnv.SelectedItem = _config.Environment;
        txtClientId.Text = _config.OAuth.ClientId;
        txtClientSecret.Text = _config.OAuth.ClientSecret;
        txtRedirectUri.Text = _config.OAuth.RedirectUri;

        _ = LoadInstruments();
        foreach (var s in _config.Symbols) AddSymbolRow(s);

        btnLogin.Click += async (s,e) => await DoLoginAsync();
        btnAdd.Click += async (s,e) => await PromptAddAsync();
        btnRemove.Click += (s,e) => RemoveSelected();
        btnBuy.Click += async (s,e) => await PlaceAsync(Txn.BUY);
        btnSell .Click += async (s,e) => await PlaceAsync(Txn.SELL);

        _strategies.OnSignal += async sig => await HandleSignalAsync(sig);
    }

    private async Task LoadInstruments()
    {
        lblStatus.Text = "Loading instruments...";
        await _inst.EnsureCacheAsync(Sandbox, CancellationToken.None);
        lblStatus.Text = "Instruments ready";
    }

    private async Task DoLoginAsync()
    {
        try
        {
            lblStatus.Text = "Logging in...";
            _accessToken = await _auth.LoginAsync(txtClientId.Text, txtClientSecret.Text, txtRedirectUri.Text, Sandbox);
            lblStatus.Text = "Logged in";
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Login error"); lblStatus.Text = "Login failed"; }
    }

    private async Task PromptAddAsync()
    {
        var sym = Microsoft.VisualBasic.Interaction.InputBox("Enter NSE trading symbol (e.g. RELIANCE)", "Add NSE Symbol", "");
        if (string.IsNullOrWhiteSpace(sym)) return;
        var info = await _inst.FindByTradingSymbolAsync(sym.Trim().ToUpperInvariant());
        if (info == null) { MessageBox.Show("Symbol not found in instruments JSON."); return; }
        AddSymbolRow(info.TradingSymbol);
    }

    private void AddSymbolRow(string symbol)
    {
        var item = new ListViewItem(new[]{ symbol, "(resolve on trade)", "Stopped", "-", "Idle"});
        listSymbols.Items.Add(item);
        // Add Start/Stop buttons per row via context menu
        var menu = new ContextMenuStrip();
        var start = new ToolStripMenuItem("Start Auto-Trade", null, (_,__) => StartAuto(symbol));
        var stop  = new ToolStripMenuItem("Stop Auto-Trade",  null, (_,__) => StopAuto(symbol));
        menu.Items.Add(start); menu.Items.Add(stop);
        listSymbols.ContextMenuStrip = menu;
    }

    private void RemoveSelected()
    {
        foreach (ListViewItem it in listSymbols.SelectedItems) listSymbols.Items.Remove(it);
    }

    private async Task PlaceAsync(Txn side)
    {
        var selected = listSymbols.SelectedItems.Count>0 ? listSymbols.SelectedItems[0] : null;
        if (selected == null) { MessageBox.Show("Select a symbol first"); return; }
        var symbol = selected.SubItems[0].Text;
        var info = await _inst.FindByTradingSymbolAsync(symbol);
        if (info == null) { MessageBox.Show("Instrument not found"); return; }

        var order = new PlaceOrder(
            InstrumentKey: info.InstrumentKey,
            Quantity: (int)numQty.Value,
            Product: Enum.Parse<Product>(cmbProduct.SelectedItem?.ToString() ?? "I"),
            OrderType: Enum.Parse<OrderType>((cmbType.SelectedItem?.ToString() ?? "MARKET").Replace("-","_")),
            TransactionType: side,
            Validity: Enum.Parse<Validity>(cmbValidity.SelectedItem?.ToString() ?? "DAY"),
            Price: numPrice.Value,
            TriggerPrice: numTrig.Value,
            IsAmo: false,
            Slice: false,
            Tag: "MANUAL"
        );

        try
        {
            lblStatus.Text = $"Placing {side} {symbol}...";
            await _orders.PlaceOrderAsync(order, Sandbox, CancellationToken.None);
            lblStatus.Text = "Order placed";
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Order error"); lblStatus.Text = "Order failed"; }
    }

    private void StartAuto(string symbol)
    {
        Task.Run(async () =>
        {
            var info = await _inst.FindByTradingSymbolAsync(symbol);
            if (info == null) return;
            _strategies.Start(info.InstrumentKey);
            UpdateRow(symbol, auto:"Running", status:"Auto ON");
        });
    }

    private void StopAuto(string symbol)
    {
        Task.Run(async () =>
        {
            var info = await _inst.FindByTradingSymbolAsync(symbol);
            if (info == null) return;
            _strategies.Stop(info.InstrumentKey);
            UpdateRow(symbol, auto:"Stopped", status:"Auto OFF");
        });
    }

    private void UpdateRow(string symbol, string? ik = null, string? auto = null, string? last = null, string? status = null)
    {
        this.Invoke(() =>
        {
            foreach (ListViewItem it in listSymbols.Items)
            {
                if (it.SubItems[0].Text.Equals(symbol, StringComparison.OrdinalIgnoreCase))
                {
                    if (ik != null) it.SubItems[1].Text = ik;
                    if (auto != null) it.SubItems[2].Text = auto;
                    if (last != null) it.SubItems[3].Text = last;
                    if (status != null) it.SubItems[4].Text = status;
                }
            }
        });
    }

    private async Task HandleSignalAsync(TradeSignal sig)
    {
        // Basic conversion of signal to order (1 lot)
        var side = sig.Side == SignalSide.Buy ? Txn.BUY : Txn.SELL;
        var order = new PlaceOrder(
            InstrumentKey: sig.InstrumentKey,
            Quantity: Math.Max(1, sig.Quantity),
            Product: Product.I,
            OrderType: OrderType.MARKET,
            TransactionType: side,
            Validity: Validity.DAY,
            Price: 0m,
            TriggerPrice: 0m,
            IsAmo: false,
            Slice: true,
            Tag: sig.StrategyId
        );

        try
        {
            await _orders.PlaceOrderAsync(order, Sandbox, CancellationToken.None);
            lblStatus.Text = $"Auto order OK: {sig.InstrumentKey} {sig.Side}";
        }
        catch (Exception ex)
        {
            lblStatus.Text = $"Auto order FAILED: {ex.Message}";
        }
    }
}
