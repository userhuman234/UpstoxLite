
using System.Net;
using System.Web;

namespace Core.Upstox;

public sealed class UpstoxAuthService : IAuthService
{
    public string? AccessToken { get; private set; }

    public async Task<string> LoginAsync(string clientId, string clientSecret, string redirectUri, bool sandbox)
    {
        // Open browser to Upstox OAuth page
        var authUrl = $"https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id={Uri.EscapeDataString(clientId)}&redirect_uri={Uri.EscapeDataString(redirectUri)}";
        var psi = new System.Diagnostics.ProcessStartInfo { FileName = authUrl, UseShellExecute = true };
        System.Diagnostics.Process.Start(psi);

        // Simple local listener on redirectUri
        using var listener = new HttpListener();
        listener.Prefixes.Add(redirectUri);
        listener.Start();
        var ctx = await listener.GetContextAsync();
        var query = ctx.Request.Url!.Query;
        var qp = HttpUtility.ParseQueryString(query);
        var code = qp["code"] ?? throw new InvalidOperationException("No auth code returned");
        var msg = System.Text.Encoding.UTF8.GetBytes("Upstox login successful. You may close this tab.");
        await ctx.Response.OutputStream.WriteAsync(msg, 0, msg.Length);
        ctx.Response.OutputStream.Close();
        listener.Stop();

        // Exchange code for token
        using var http = new HttpClient();
        var tokenUrl = "https://api.upstox.com/v2/login/authorization/token";
        var form = new FormUrlEncodedContent(new Dictionary<string,string>{
            ["code"] = code,
            ["client_id"] = clientId,
            ["client_secret"] = clientSecret,
            ["redirect_uri"] = redirectUri,
            ["grant_type"] = "authorization_code"
        });
        var resp = await http.PostAsync(tokenUrl, form);
        resp.EnsureSuccessStatusCode();
        var json = await resp.Content.ReadAsStringAsync();
        var doc = System.Text.Json.JsonDocument.Parse(json);
        AccessToken = doc.RootElement.GetProperty("access_token").GetString();
        return AccessToken!;
    }
}
