
using Core.Shared.Models;

namespace Core.Engine;

public interface IStrategyHost
{
    void Start(string instrumentKey);
    void Stop(string instrumentKey);
    event Action<TradeSignal>? OnSignal;
}

public sealed class StrategyHost : IStrategyHost
{
    private readonly HashSet<string> _running = new();
    private readonly Timer _timer;

    public event Action<TradeSignal>? OnSignal;

    public StrategyHost()
    {
        // Simple heartbeat driving decisions (placeholder).
        _timer = new Timer(_ => Tick(), null, Timeout.Infinite, Timeout.Infinite);
    }

    public void Start(string instrumentKey)
    {
        if (_running.Add(instrumentKey) && _running.Count == 1)
            _timer.Change(1000, 1000); // 1s cadence
    }

    public void Stop(string instrumentKey)
    {
        _running.Remove(instrumentKey);
        if (_running.Count == 0) _timer.Change(Timeout.Infinite, Timeout.Infinite);
    }

    private void Tick()
    {
        // TODO: Replace with real tick-driven logic.
        foreach (var ik in _running)
        {
            var ts = DateTime.UtcNow;
            var side = (ts.Second % 30 == 0) ? SignalSide.Buy : (ts.Second % 45 == 0) ? SignalSide.Sell : (SignalSide?)null;
            if (side == null) continue;
            OnSignal?.Invoke(new TradeSignal(
                StrategyId: "VWAP-Confluence",
                InstrumentKey: ik,
                TimestampUtc: ts,
                Side: side.Value,
                Quantity: 1,
                Reason: "Timer pulse demo (replace with indicators)",
                Confidence: 0.5m
            ));
        }
    }
}
