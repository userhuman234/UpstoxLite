
param()
# Create solution and add projects
if (!(Test-Path UpstoxLite.sln)) {
  dotnet new sln -n UpstoxLite
}

# Create solution folders (logical)
$projects = @(
  'Core.Shared/Core.Shared.csproj',
  'Core.Engine/Core.Engine.csproj',
  'Core.Upstox/Core.Upstox.csproj',
  'App.WinForms/App.WinForms.csproj'
)
foreach ($p in $projects) {
  if (Test-Path $p) { dotnet sln add $p }
}
