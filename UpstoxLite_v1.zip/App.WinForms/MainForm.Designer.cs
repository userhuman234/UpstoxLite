
namespace App.WinForms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private TabControl tabs;
        private TabPage tabTrade;
        private TabPage tabSettings;
        private ListView listSymbols;
        private Button btnAdd;
        private Button btnRemove;
        private Button btnLogin;
        private TextBox txtClientId, txtClientSecret, txtRedirectUri;
        private ComboBox cmbEnv;
        private Label lblEnv;
        private GroupBox grpManual;
        private ComboBox cmbProduct, cmbType, cmbValidity;
        private NumericUpDown numQty, numPrice, numTrig;
        private Button btnBuy, btnSell;
        private StatusStrip status;
        private ToolStripStatusLabel lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.Text = "UpstoxLite";
            this.Width = 980; this.Height = 640;

            tabs = new TabControl(){Dock = DockStyle.Fill};
            tabTrade = new TabPage("Trade");
            tabSettings = new TabPage("Settings");
            tabs.TabPages.AddRange(new[]{tabTrade, tabSettings});
            Controls.Add(tabs);

            // Trade Tab
            listSymbols = new ListView(){ View = View.Details, FullRowSelect = true, Dock = DockStyle.Fill };
            listSymbols.Columns.Add("Symbol", 120);
            listSymbols.Columns.Add("InstrumentKey", 240);
            listSymbols.Columns.Add("Auto-Trade", 100);
            listSymbols.Columns.Add("Last", 80);
            listSymbols.Columns.Add("Status", 200);

            var pnlTop = new FlowLayoutPanel(){ Dock = DockStyle.Top, Height = 40 };
            btnAdd = new Button(){ Text = "+ Add NSE" };
            btnRemove = new Button(){ Text = "- Remove" };
            pnlTop.Controls.AddRange(new Control[]{ btnAdd, btnRemove });

            grpManual = new GroupBox(){ Text = "Manual Trade", Dock = DockStyle.Bottom, Height = 120 };
            cmbProduct = new ComboBox(){ DropDownStyle = ComboBoxStyle.DropDownList, Width = 80 };
            cmbProduct.Items.AddRange(new[]{"I","D","MTF"});
            cmbType = new ComboBox(){ DropDownStyle = ComboBoxStyle.DropDownList, Width = 100 };
            cmbType.Items.AddRange(new[]{"MARKET","LIMIT","SL","SL-M"});
            cmbValidity = new ComboBox(){ DropDownStyle = ComboBoxStyle.DropDownList, Width = 80 };
            cmbValidity.Items.AddRange(new[]{"DAY","IOC"});
            numQty = new NumericUpDown(){ Minimum=1, Maximum=100000, Value=1, Width=80 };
            numPrice = new NumericUpDown(){ Minimum=0, Maximum=1000000, DecimalPlaces=2, Increment=0.05m, Width=100 };
            numTrig = new NumericUpDown(){ Minimum=0, Maximum=1000000, DecimalPlaces=2, Increment=0.05m, Width=100 };
            btnBuy = new Button(){ Text = "BUY", Width = 80 };
            btnSell = new Button(){ Text = "SELL", Width = 80 };

            var flow = new FlowLayoutPanel(){ Dock = DockStyle.Fill };
            flow.Controls.AddRange(new Control[]{ new Label(){Text="Product"}, cmbProduct, new Label(){Text="Type"}, cmbType,
                new Label(){Text="Validity"}, cmbValidity, new Label(){Text="Qty"}, numQty,
                new Label(){Text="Price"}, numPrice, new Label(){Text="Trigger"}, numTrig, btnBuy, btnSell});
            grpManual.Controls.Add(flow);

            var tradePanel = new Panel(){ Dock = DockStyle.Fill };
            tradePanel.Controls.Add(listSymbols);
            tradePanel.Controls.Add(pnlTop);
            tradePanel.Controls.Add(grpManual);
            tabTrade.Controls.Add(tradePanel);

            // Settings Tab
            var setFlow = new TableLayoutPanel(){ Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 5 };
            setFlow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            setFlow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            lblEnv = new Label(){Text="Environment"};
            cmbEnv = new ComboBox(){ DropDownStyle = ComboBoxStyle.DropDownList };
            cmbEnv.Items.AddRange(new[]{"Sandbox","Live"});
            txtClientId = new TextBox();
            txtClientSecret = new TextBox(){ UseSystemPasswordChar = true };
            txtRedirectUri = new TextBox();
            btnLogin = new Button(){ Text = "Login to Upstox" };

            setFlow.Controls.Add(lblEnv,0,0); setFlow.Controls.Add(cmbEnv,1,0);
            setFlow.Controls.Add(new Label(){Text="Client Id"},0,1); setFlow.Controls.Add(txtClientId,1,1);
            setFlow.Controls.Add(new Label(){Text="Client Secret"},0,2); setFlow.Controls.Add(txtClientSecret,1,2);
            setFlow.Controls.Add(new Label(){Text="Redirect Uri"},0,3); setFlow.Controls.Add(txtRedirectUri,1,3);
            setFlow.Controls.Add(btnLogin,1,4);
            tabSettings.Controls.Add(setFlow);

            // Status bar
            status = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("Ready");
            status.Items.Add(lblStatus);
            Controls.Add(status);
        }
    }
}
