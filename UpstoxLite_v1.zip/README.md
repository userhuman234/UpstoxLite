
# UpstoxLite (WinForms, .NET 8, single EXE)

A lightweight Windows trading client that connects to Upstox for manual and automatic trading, with per-symbol Start/Stop auto-trade controls.

> **IMPORTANT**: Use **Sandbox** first, then switch to **Live** only after validating. You are responsible for all trading risks.

## Features in this MVP
- Single EXE (publish trimmed, self-contained)
- OAuth 2.0 login to Upstox (opens browser, local redirect listener)
- Instruments loader (Upstox BOD JSON -> local SQLite cache)
- Watchlist with **TATASTEEL**, **ICICIBANK**, **INFY** preloaded; add/remove NSE symbols
- Manual Buy/Sell panel (I/D/MTF, MARKET/LIMIT/SL/SL-M, DAY/IOC)
- Auto-trade Start/Stop per symbol (basic strategy host)
- Order placement via Place Order V3; Multi-Order scaffolding (with 4 req/s limiter)
- Rate-limit aware (standard 50 req/s; multi-order 4 req/s) with retry/backoff
- Market data: WebSocket V3 scaffolding (Protobuf parser hook); **temporary REST LTP fallback** is enabled until you paste the official .proto and generate C# types

## Quick start
1. Install [.NET 8 SDK](https://dotnet.microsoft.com/).
2. Open **Developer PowerShell** in this folder and run:
   ```powershell
   ./setup.ps1
   dotnet restore
   dotnet build
   dotnet run --project App.WinForms
   ```
3. In the app, go to **Settings → Environment** and select **Sandbox**. Enter your Sandbox `client_id`, `client_secret` and click **Login**.
4. Validate manual orders on TATASTEEL/ICICIBANK/INFY in **Sandbox**.
5. Switch **Environment** to **Live** only after testing.

## Publish single-file EXE
```powershell
# x64 trimmed single-file
 dotnet publish App.WinForms -c Release -r win10-x64    /p:PublishSingleFile=true /p:PublishTrimmed=true    /p:IncludeNativeLibrariesForSelfExtract=true
```

## Notes
- To enable **Market Data V3** decoding, download the official `MarketDataFeedV3.proto` from Upstox docs, generate C# classes using `protoc`, and place the generated `.cs` file under `Core.Upstox/Proto`. Update `MarketDataV3Client.cs` to use the generated types.
- All Upstox endpoints and limits must be respected. This code includes limiters and retry with backoff, but you should review before Live.

## References
- Upstox Authentication (OAuth 2.0): https://upstox.com/developer/api-documentation/authentication/
- Market Data Feed V3 (WebSocket, Protobuf): https://upstox.com/developer/api-documentation/v3/get-market-data-feed/
- Rate Limits (incl. Multi-Order 4 req/s): https://upstox.com/developer/api-documentation/rate-limiting/
- Place Order V3 & Place Multi Order: 
  - https://upstox.com/developer/api-documentation/v3/place-order/
  - https://upstox.com/developer/api-documentation/place-multi-order/
- Instruments (BOD JSON, use instrument_key): https://upstox.com/developer/api-documentation/instruments/
- WebSocket rate-limit note (community): https://community.upstox.com/t/rate-limits-in-websocket/6943
