
using System.Text.Json;
using Core.Upstox;
using Core.Engine;

namespace App.WinForms;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        var config = JsonSerializer.Deserialize<Config>(File.ReadAllText("appsettings.json"))!;
        var auth = new UpstoxAuthService();
        var inst = new InstrumentsService(Path.Combine(AppContext.BaseDirectory, "data"));
        var orders = new OrderClient();
        var strat = new StrategyHost();

        var form = new MainForm(config, auth, inst, orders, strat);
        Application.Run(form);
    }
}

public record Config
{
    public string Environment { get; init; } = "Sandbox";
    public OAuthConfig OAuth { get; init; } = new();
    public List<string> Symbols { get; init; } = new();
}

public record OAuthConfig
{
    public string ClientId { get; init; } = string.Empty;
    public string ClientSecret { get; init; } = string.Empty;
    public string RedirectUri { get; init; } = "http://localhost:11400/";
}
