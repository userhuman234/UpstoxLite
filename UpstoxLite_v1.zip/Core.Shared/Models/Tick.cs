
namespace Core.Shared.Models;

public record Tick(
    string InstrumentKey,
    DateTime TimestampUtc,
    decimal Ltp,
    decimal Bid,
    decimal Ask,
    decimal Volume
);
