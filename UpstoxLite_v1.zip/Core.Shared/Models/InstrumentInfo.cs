
namespace Core.Shared.Models;

public record InstrumentInfo(
    string InstrumentKey,
    string TradingSymbol,
    string Segment,
    string InstrumentType,
    string ISIN,
    int LotSize,
    decimal FreezeQuantity,
    decimal TickSize
);
