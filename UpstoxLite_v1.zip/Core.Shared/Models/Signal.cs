
namespace Core.Shared.Models;

public enum SignalSide { Buy, Sell }

public record TradeSignal(
    string StrategyId,
    string InstrumentKey,
    DateTime TimestampUtc,
    SignalSide Side,
    int Quantity,
    string Reason,
    decimal Confidence
);
