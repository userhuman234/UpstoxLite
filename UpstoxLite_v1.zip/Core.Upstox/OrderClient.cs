
using Core.Shared.Models;
using Core.Shared.Utils;
using System.Text;
using System.Text.Json;

namespace Core.Upstox;

public sealed class OrderClient : IOrderClient
{
    private readonly RateLimiter _stdLimiter = new(50);   // Standard APIs
    private readonly RateLimiter _multiLimiter = new(4);  // Multi-Order API

    public async Task PlaceOrderAsync(PlaceOrder order, bool sandbox, CancellationToken ct)
    {
        var url = "https://api.upstox.com/v2/order/place"; // V3 endpoint is documented separately
        var body = new
        {
            quantity = order.Quantity,
            product = order.Product.ToString(),
            validity = order.Validity.ToString(),
            price = order.Price,
            tag = order.Tag,
            instrument_token = order.InstrumentKey,
            order_type = order.OrderType.ToString().Replace("_", "-"),
            transaction_type = order.TransactionType.ToString(),
            disclosed_quantity = 0,
            trigger_price = order.TriggerPrice,
            is_amo = order.IsAmo,
            slice = order.Slice
        };

        await RetryPolicy.ExecuteAsync(async () =>
        {
            var tcs = new TaskCompletionSource();
            _stdLimiter.Enqueue(async () =>
            {
                using var http = new HttpClient();
                // NOTE: Access token should be set globally; here we expect default handler to inject it.
                var json = JsonSerializer.Serialize(body, new JsonSerializerOptions { IgnoreNullValues = true });
                var req = new HttpRequestMessage(HttpMethod.Post, url);
                req.Headers.TryAddWithoutValidation("Accept", "application/json");
                // Authorization header must be set by caller (e.g., HttpClientFactory)
                req.Content = new StringContent(json, Encoding.UTF8, "application/json");
                var resp = await http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                tcs.SetResult();
            });
            await tcs.Task;
        });
    }

    public async Task PlaceMultiOrderAsync(IEnumerable<MultiOrderLine> lines, bool sandbox, CancellationToken ct)
    {
        var url = "https://api.upstox.com/v2/order/multi/place"; // per docs
        var payload = lines.Select(l => new
        {
            correlation_id = l.CorrelationId,
            quantity = l.Order.Quantity,
            product = l.Order.Product.ToString(),
            validity = l.Order.Validity.ToString(),
            price = l.Order.Price,
            tag = l.Order.Tag,
            instrument_token = l.Order.InstrumentKey,
            order_type = l.Order.OrderType.ToString().Replace("_", "-"),
            transaction_type = l.Order.TransactionType.ToString(),
            disclosed_quantity = 0,
            trigger_price = l.Order.TriggerPrice,
            is_amo = l.Order.IsAmo,
            slice = l.Order.Slice
        }).ToArray();

        await RetryPolicy.ExecuteAsync(async () =>
        {
            var tcs = new TaskCompletionSource();
            _multiLimiter.Enqueue(async () =>
            {
                using var http = new HttpClient();
                var json = JsonSerializer.Serialize(payload);
                var req = new HttpRequestMessage(HttpMethod.Post, url);
                req.Headers.TryAddWithoutValidation("Accept", "application/json");
                req.Content = new StringContent(json, Encoding.UTF8, "application/json");
                var resp = await http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                tcs.SetResult();
            });
            await tcs.Task;
        });
    }
}
