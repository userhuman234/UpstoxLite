
using System.Net.WebSockets;
using System.Text;

namespace Core.Upstox;

public sealed class MarketDataV3Client : IMarketDataClient
{
    private ClientWebSocket? _ws;

    public async Task ConnectAsync(string accessToken, bool sandbox, CancellationToken ct)
    {
        _ws = new ClientWebSocket();
        _ws.Options.SetRequestHeader("Authorization", $"Bearer {accessToken}");
        var uri = new Uri("wss://api-v2.upstox.com/feed/market-data-v3");
        await _ws.ConnectAsync(uri, ct);
    }

    public async Task SubscribeAsync(IEnumerable<string> instrumentKeys, string mode = "full", CancellationToken ct = default)
    {
        if (_ws == null) throw new InvalidOperationException("Not connected");
        // Build a minimal JSON sub message; NOTE: V3 expects binary protobuf. This is a placeholder
        string msg = $"{{"guid":"{Guid.NewGuid():N}","method":"sub","data":{{"mode":"{mode}","instrumentKeys":[{string.Join(',', instrumentKeys.Select(k=>"""+k+"""))}]}}}}";
        var bytes = Encoding.UTF8.GetBytes(msg);
        await _ws.SendAsync(bytes, WebSocketMessageType.Text, true, ct);
    }

    public async ValueTask DisposeAsync()
    {
        if (_ws != null)
        {
            try { await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "bye", CancellationToken.None); } catch {}
            _ws.Dispose();
        }
    }
}
