
using System.Threading.Channels;

namespace Core.Shared.Utils;

public sealed class RateLimiter
{
    private readonly Channel<Func<Task>> _queue = Channel.CreateUnbounded<Func<Task>>();
    private readonly int _maxPerSecond;

    public RateLimiter(int maxPerSecond)
    {
        _maxPerSecond = maxPerSecond;
        _ = Pump();
    }

    public void Enqueue(Func<Task> work) => _queue.Writer.TryWrite(work);

    private async Task Pump()
    {
        var window = TimeSpan.FromSeconds(1);
        var stamps = new Queue<DateTime>();
        await foreach (var work in _queue.Reader.ReadAllAsync())
        {
            while (stamps.Count >= _maxPerSecond && (DateTime.UtcNow - stamps.Peek()) < window)
                await Task.Delay(5);

            _ = Task.Run(async () =>
            {
                try { await work(); }
                finally
                {
                    var now = DateTime.UtcNow;
                    stamps.Enqueue(now);
                    while (stamps.Count > 0 && (now - stamps.Peek()) >= window) stamps.Dequeue();
                }
            });
        }
    }
}
