
using System.Net;

namespace Core.Shared.Utils;

public static class RetryPolicy
{
    private static readonly Random Rng = new();

    public static async Task<T> ExecuteAsync<T>(Func<Task<T>> work, int maxRetries = 5)
    {
        int attempt = 0;
        while (true)
        {
            try { return await work(); }
            catch (HttpRequestException ex) when (attempt < maxRetries)
            {
                attempt++;
                var delay = BackoffDelay(attempt);
                await Task.Delay(delay);
            }
        }
    }

    public static async Task ExecuteAsync(Func<Task> work, int maxRetries = 5)
    {
        await ExecuteAsync(async () => { await work(); return true; }, maxRetries);
    }

    private static TimeSpan BackoffDelay(int attempt)
    {
        // Exponential backoff with jitter
        var baseMs = Math.Pow(2, attempt) * 100; // 100ms, 200ms, 400ms, ...
        var jitter = Rng.Next(0, 250);
        return TimeSpan.FromMilliseconds(baseMs + jitter);
    }
}
