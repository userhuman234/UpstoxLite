
using Core.Shared.Models;

namespace Core.Upstox;

public interface IAuthService
{
    Task<string> LoginAsync(string clientId, string clientSecret, string redirectUri, bool sandbox);
    string? AccessToken { get; }
}

public interface IInstrumentsService
{
    Task EnsureCacheAsync(bool sandbox, CancellationToken ct);
    Task<InstrumentInfo?> FindByTradingSymbolAsync(string tradingSymbol, string segment = "NSE_EQ", string instrumentType = "EQ");
}

public interface IOrderClient
{
    Task PlaceOrderAsync(PlaceOrder order, bool sandbox, CancellationToken ct);
    Task PlaceMultiOrderAsync(IEnumerable<MultiOrderLine> lines, bool sandbox, CancellationToken ct);
}

public interface IMarketDataClient : IAsyncDisposable
{
    Task ConnectAsync(string accessToken, bool sandbox, CancellationToken ct);
    Task SubscribeAsync(IEnumerable<string> instrumentKeys, string mode = "full", CancellationToken ct = default);
}
